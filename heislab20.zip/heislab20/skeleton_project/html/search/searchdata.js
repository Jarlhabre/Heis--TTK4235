var indexSectionsWithContent =
{
  0: "cdeghorsu",
  1: "hos",
  2: "cdeghorsu",
  3: "h"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "enums"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Enumerations"
};

