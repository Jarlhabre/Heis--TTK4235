var searchData=
[
  ['check_5fbelow',['check_below',['../orders_8h.html#ad5e1f8e4994c060c0e0108d4b5d0221d',1,'orders.c']]],
  ['check_5fif_5fstop',['check_if_stop',['../orders_8h.html#a7792c95805c4e8664cb0197b59c71fba',1,'orders.c']]],
  ['clear_5fall_5forder_5flights',['clear_all_order_lights',['../sensor_8h.html#afd77151474c3e94d7c52fd75413ae3ca',1,'sensor.c']]],
  ['clear_5fall_5forders',['clear_all_orders',['../orders_8h.html#a6206e5203639ca23d84820e2ffb108a3',1,'orders.c']]],
  ['clear_5ffloor_5forders',['clear_floor_orders',['../orders_8h.html#ae1d0119c956fb06ac40c77c536a59ea8',1,'orders.c']]]
];
