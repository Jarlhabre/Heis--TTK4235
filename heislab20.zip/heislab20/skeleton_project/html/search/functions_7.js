var searchData=
[
  ['set_5fcurrent_5ffloor',['set_current_floor',['../orders_8h.html#af301ad8ab309faad715b42cec68055af',1,'orders.c']]],
  ['set_5felevator_5fmovement',['set_elevator_movement',['../orders_8h.html#a85515b059e1733d8c2c87916aef93b51',1,'orders.c']]],
  ['startup',['startup',['../heis_8h.html#aecc7d8debf54990ffeaaed5bac7d7d81',1,'heis.c']]],
  ['stop_5fbutton',['stop_button',['../orders_8h.html#ab17ee675489c70d5b3b394827c5e6b17',1,'orders.c']]]
];
