var searchData=
[
  ['update_5forders',['update_orders',['../orders_8h.html#aae689380ca1910da3e975271fa399cb3',1,'orders.c']]]
];
