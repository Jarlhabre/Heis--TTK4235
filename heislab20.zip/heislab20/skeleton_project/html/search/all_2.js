var searchData=
[
  ['execute_5forder',['execute_order',['../orders_8h.html#a614cc8c17076e921ba5f616f85080b34',1,'orders.c']]]
];
