var searchData=
[
  ['get_5ffloor',['get_floor',['../sensor_8h.html#ac2d21893332aa2bfe4dcae13d4acdbda',1,'sensor.c']]],
  ['go_5fto_5ffloor',['go_to_floor',['../orders_8h.html#a8141c36b99171245290347e19c5f18d0',1,'orders.c']]]
];
