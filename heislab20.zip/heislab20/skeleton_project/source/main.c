#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include "hardware.h"
#include "heis.h"




int main(){
    run();
}
